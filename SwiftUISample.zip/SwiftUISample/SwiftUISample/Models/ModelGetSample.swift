//
//  ModelGetSample.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/17/21.
//

import Foundation

struct ModelGetSample: Decodable {
    
    var page: Int?
    var per_page: Int?
    var total: Int?
    var total_pages: Int?
    var data: [UserData]?
}

struct UserData: Decodable, Identifiable {
    
    var id:Int?
    var email: String?
    var first_name: String?
    var last_name: String?
    var avatar: String?
}
