//
//  ModelPostSample.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/19/21.
//

import Foundation

struct ModelPostSample: Decodable {
    
    var name: String?
    var job: String?
    var id: String?
    var createdAt: String?
}
