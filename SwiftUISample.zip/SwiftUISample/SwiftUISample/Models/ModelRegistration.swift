//
//  ModelRegistration.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/24/21.
//

import Foundation

struct ModelRegistration: Decodable {
    
    var id: Int?
    var token: String?
    var error: String?
}
