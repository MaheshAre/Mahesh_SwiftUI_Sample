//
//  ModelEmp.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/16/21.
//

import Foundation
import SwiftUI

struct ModelEmp: Identifiable {
    
    var id: Int?
    var name: String?
    var age: Int?
}
