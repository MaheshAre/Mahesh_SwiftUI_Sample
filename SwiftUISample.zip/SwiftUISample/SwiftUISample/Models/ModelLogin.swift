//
//  ModelLogin.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/22/21.
//

import Foundation

struct ModelLogin: Decodable {
    
    var token: String?
    var message: String?
    
    var id: Int?
}
