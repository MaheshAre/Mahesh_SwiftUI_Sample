//
//  PostRequestView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/19/21.
//

import SwiftUI

struct PostRequestView: View {
    
    @ObservedObject var postData = VMPostSample()
    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 10, content: {
            HStack {
                
                Text("ID: ")
                    .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 18)
                
                Text(postData.data.id ?? "")
                    .setFont(FontName: Enum_FontName.HelveticaNeue_regular.rawValue, FontSize: 18)
                
                Spacer()
            }
            
            HStack {
                
                Text("name: ")
                    .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 18)
                
                Text((postData.data.name ?? "").firstUppercased)
                    .setFont(FontName: Enum_FontName.HelveticaNeue_regular.rawValue, FontSize: 18)
            }
            
            HStack {
                
                Text("Job: ")
                    .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 18)
                
                Text((postData.data.job ?? "").firstCapitalized)
                    .setFont(FontName: Enum_FontName.HelveticaNeue_regular.rawValue, FontSize: 18)
            }
            
        })
        .navigationTitle("Post Request Sample")
        .setShadow(CornerRadius: 15, ShadowColor: nil)
        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/,maxHeight: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .top)
        .padding()
        .offset(x: 0, y: 20)
        
    }
}

struct PostRequestView_Previews: PreviewProvider {
    static var previews: some View {
        PostRequestView(postData: VMPostSample())
    }
}
