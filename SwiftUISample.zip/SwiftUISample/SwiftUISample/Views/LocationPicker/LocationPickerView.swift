//
//  LocationPickerView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/11/21.
//

import SwiftUI
import CoreLocation

struct LocationPickerView: View {
    
    @Environment(\.viewController) private var viewControllerHolder: UIViewController?
            
    @ObservedObject var locationManager = LocationManager()
    
    var body: some View {
        
        VStack {
            
            NavigationButton(destination: {
                
                LocationsView()
            }, label: {
                Text("Current Location")
            })
            .default_ButtonStyle()
            .padding()
            
            NavigationButton(destination: {
                
                PickLocation_MapView(locationManager: self.locationManager)
            }, label: {
                Text("Select Location From Map")
            })
            .default_ButtonStyle()
            .padding()
            
            Text(self.locationManager.addressStruct?.formattedAddress ?? "Selected Address")
            Text(self.locationManager.coordinate?.coordinateStr ?? "Coordinates")
            
            
        }
        .navigationTitle("Location Picker")
    }
}

struct LocationPickerView_Previews: PreviewProvider {
    static var previews: some View {
        LocationPickerView()
    }
}
