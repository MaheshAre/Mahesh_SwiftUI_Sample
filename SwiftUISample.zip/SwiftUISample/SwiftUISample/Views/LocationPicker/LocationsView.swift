//
//  LocationsView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/10/21.
//

import SwiftUI
import CoreLocation

struct LocationsView: View {
            
    @ObservedObject var locationManager = LocationManager()
    
    var currentLat: Double {
        return self.locationManager.lat ?? 0.0
    }
    
    var currentLong: Double {
        return self.locationManager.long ?? 0.0
    }
    
    var currentCoordinate: CLLocationCoordinate2D {
        return self.locationManager.coordinate ?? CLLocationCoordinate2D(latitude: 0.0, longitude: 0.0)
    }
    
    init() {
//        print(self.gpsLocation.coordinates)
//        print(self.gpsLocation.userLatitude)
    }
    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 15, content: {
           
//            Text("\(self.currentLat)")
//            Text("\(self.currentLong)")
            
            Text("\(self.locationManager.addressStruct?.formattedAddress ?? "Address")")
                        
        })
        .padding()
        .navigationTitle("Locations")

    }
    
}

struct LocationsView_Previews: PreviewProvider {
    static var previews: some View {
        LocationsView()
    }
}

