//
//  DropDownView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/24/21.
//

import SwiftUI

struct DropDownView: View {
    
    var dropDownArray = ["Abc", "Def", "Ghi", "Jkl", "Mnop"]

    @State var selectedString = ""
    var body: some View {
        
        CustomUIButton(title: "Drop Down",backGroundColor: .secondaryLabel, foregroundColor: .white, cornerRed: 10, action: { (btn) in
            
            FTPopoverClass.showPopover(Sender: btn, Width: 100, DataArray: self.dropDownArray, ImagesArray: nil) { (selectedIndex) in
                self.selectedString = self.dropDownArray[selectedIndex]
            }
        })
        .frame(width: screenWidth-30, height: 50, alignment: .center)
        
        Text(self.selectedString)
            .navigationTitle("Drop Down")
        
    }
}

struct DropDownView_Previews: PreviewProvider {
    static var previews: some View {
        DropDownView()
    }
}
