//
//  HomeView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/15/21.
//

import SwiftUI
//import LanguageManager_iOS

struct HomeView: View  {
    
    @State var vmLogin: VMLogin // = "Token"
    @State var enumCommingFrom = Enum_CommingFromView.loginView
    @State var isShowBackBtn = false
    
    @Environment(\.viewController) private var viewControllerHolder: UIViewController?
                    
    var body: some View {
        
        VStack {
            
            if self.enumCommingFrom == .registrationView {
                Text("ID: \t\(self.vmLogin.vmLogin.id ?? 0)")
                    .padding()
            }
            
            Text("Token: \t\(self.vmLogin.vmLogin.token ?? "TOKEN")")
                .padding(.bottom, 20)
            
            NavigationButton(action: { }, destination: {
                ContentView()
            }, label: {
                Text("Main Screen".localized)
            })
            .buttonStyle(CustomButtonStyle(backGroundColor: Color.secondary, foregroundColor: Color.white, cornerRed: 10, width: 200, height: 50, alignment: Alignment.center))
            
        }
        .navigationTitle("Home".localized)
        .navigationBarBackButtonHidden(self.isShowBackBtn)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
        
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView(vmLogin: VMLogin())
    }
}

