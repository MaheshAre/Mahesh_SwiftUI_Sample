//
//  GetUserDetailsView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/19/21.
//

import SwiftUI
import SDWebImageSwiftUI
import SDWebImage

struct GetUserDetailsView: View {
    
    var userDetails = UserData()
    
    init(data: UserData) {
        self.userDetails = data
    }
    
    var body: some View {
        
        VStack {
            
            WebImage(url: URL(string: self.userDetails.avatar!), options: .progressiveLoad, context: .none)
                .placeholder(Image.img_placeHolder)
                .cornerRadius(15)
                .padding(5)
//                .scaledToFit()
//                .frame(width: 200, height: 200, alignment: .center)
                
            
            VStack(alignment: .leading, spacing: 10, content: {
                                
                HStack {
                    Text("ID: ")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 18)
                    
                    Text("\(userDetails.id ?? 0)")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_regular.rawValue, FontSize: 18)
                    Spacer()
                }
                
                
                HStack(alignment: .top, spacing: /*@START_MENU_TOKEN@*/nil/*@END_MENU_TOKEN@*/, content: {
                    Text("First Name: ")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 18)
                    
                    Text(userDetails.first_name ?? "")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_regular.rawValue, FontSize: 18)
                })
                
                HStack(alignment: .top, spacing: /*@START_MENU_TOKEN@*/nil/*@END_MENU_TOKEN@*/, content: {
                    Text("Last Name: ")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 18)
                    
                    Text(userDetails.last_name ?? "")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_regular.rawValue, FontSize: 18)
                })
                
                HStack(alignment: .top, spacing: /*@START_MENU_TOKEN@*/nil/*@END_MENU_TOKEN@*/, content: {
                    Text("Email: ")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 18)
                    
                    Text(userDetails.email ?? "")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_regular.rawValue, FontSize: 18)
                })
                
                
            })
            .padding(15)
        }
        .navigationTitle("User Full Details")
        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, maxHeight: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .top)
        
    }
}

struct GetUserDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        GetUserDetailsView(data: UserData(id: 0, email: "amam", first_name: "aah", last_name: "sa", avatar: "placeHolder"))
    }
}
