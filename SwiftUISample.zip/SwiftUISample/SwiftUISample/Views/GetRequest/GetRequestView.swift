//
//  GetRequestView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/15/21.
//

import SwiftUI
import UIKit

struct GetRequestView: View {
    
    @ObservedObject var vmGetObj = VMGet()
    
    var body: some View {
        
        
        List(self.vmGetObj.data, id: \.id) { data in
            UsersListView(data: data)
        }
        .navigationTitle("Get Request Sample")
        .animation(.easeInOut)
        .onAppear() {
            UITableView.appearance().separatorStyle = .singleLine
            UITableView.appearance().separatorStyle = .none
            UITableView.appearance().showsVerticalScrollIndicator = false
            UITableView.appearance().separatorColor = .systemRed
        }
        .offset(x: 0, y: 10)
        .onAppear() {
            
            self.vmGetObj.servicGETRequest()
        }
        
    }

}

struct GetRequestView_Previews: PreviewProvider {
    static var previews: some View {
        GetRequestView()
    }
}

