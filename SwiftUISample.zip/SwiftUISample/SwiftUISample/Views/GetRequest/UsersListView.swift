//
//  UsersListView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/19/21.
//

import SwiftUI
import SDWebImageSwiftUI
import SDWebImage

struct UsersListView: View {
    
    var data = UserData()
    
    init(data: UserData) {
        self.data = data
    }
    
    var body: some View {
        
        HStack {
            
            SetupUI(data: self.data)
            
            NavigationLink(
                destination: GetUserDetailsView(data: self.data),
                label: {
                    
                })
                .buttonStyle(PlainButtonStyle()).frame(width:0).opacity(0)
            
        }
        .setShadow(CornerRadius: 10, ShadowColor: nil)
        
    }
    
}

extension UsersListView {
    
    struct SetupUI: View {
        
        var data = UserData()
        
        var body: some View {
            
            WebImage(url: URL(string: data.avatar!), options: .progressiveLoad)
                .placeholder(Image.img_placeHolder)
                .indicator(.activity)
                .frame(width: 120, height: 120, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .cornerRadius(15)
            
            
            VStack(alignment: .leading, spacing: 8, content: {
                
                HStack {
                    Text("ID: ")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 18)
                    
                    Text("\(data.id ?? 0)")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_regular.rawValue, FontSize: 18)
                    Spacer()
                }
                
                
                HStack(alignment: .top, spacing: /*@START_MENU_TOKEN@*/nil/*@END_MENU_TOKEN@*/, content: {
                    Text("First Name: ")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 18)
                    
                    Text(data.first_name ?? "")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_regular.rawValue, FontSize: 18)
                })
                
                HStack(alignment: .top, spacing: /*@START_MENU_TOKEN@*/nil/*@END_MENU_TOKEN@*/, content: {
                    Text("Last Name: ")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 18)
                    
                    Text(data.last_name ?? "")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_regular.rawValue, FontSize: 18)
                })
                
                HStack(alignment: .top, spacing: /*@START_MENU_TOKEN@*/nil/*@END_MENU_TOKEN@*/, content: {
                    Text("Email: ")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 18)
                    
                    Text(data.email ?? "")
                        .setFont(FontName: Enum_FontName.HelveticaNeue_regular.rawValue, FontSize: 18)
                })
            })
            .offset(x: 5, y: 5)
            
        }
    }
}

struct UsersListView_Previews: PreviewProvider {
    static var previews: some View {
        UsersListView(data: UserData(id: 1, email: "abc@gmail.com", first_name: "Abc", last_name: "A", avatar: "placeHolder"))
    }
}

