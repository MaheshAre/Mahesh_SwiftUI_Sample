//
//  MenuContent.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/10/21.
//

import SwiftUI


struct MenuContent: View {
    
    @State var isLoggedOut = false
    
    @ObservedObject var vmMenuItems = VMMenuItem()
                
    var body: some View {
        
        List {
            
            ForEach(Array(zip(1..., self.vmMenuItems.menu_items)), id: \.1.id) { index, data in
                
                if index == 1 {
                    
                    ZStack {
                        NavigationLink(destination: Text("My Profile")) {
                            
                        }
                        .opacity(0)
                        MenuItemView(menuItem: data)
                        
                    }
                    
                }else if index == 2 {
                    
                    ZStack {
                        NavigationLink(destination: Text("Post Request")) {
                            
                        }
                        .opacity(0)
                        MenuItemView(menuItem: data)
                    }
                    
                }else if index == 3 {
                    
                    ZStack {
                        
//                        NavigationLink(destination: LoginView(enumComingFrom: .loginView, language: self.language, isShowBackBtn: true)) {
//                            //
//                        }
//                        .opacity(0)
//                        MenuItemView(menuItem: data)
                    }
                }
                
            }
        }
    }
}

struct MenuContent_Previews: PreviewProvider {
    static var previews: some View {
        MenuContent()
    }
}


//MARK:- ViewModel

class VMMenuItem:NSObject, ObservableObject {
    
    @Published var id = UUID()
    @Published var menu_items = [MenuItemStructure]()
    
    override init() {
        
        self.menu_items = [MenuItemStructure(title: "My Profile", img: Image.img_placeHolder),
                           MenuItemStructure(title: "Posts", img: Image.img_placeHolder),
                           MenuItemStructure(title: "Logout", img: Image.img_placeHolder)]
    }
    
}

//MARK:- Model
struct MenuItemStructure: Identifiable {
    
    var id = UUID()
    var title: String?
    var img: Image?
}

