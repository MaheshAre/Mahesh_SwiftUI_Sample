//
//  SideMenuView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/10/21.
//

import SwiftUI

struct SideMenuView: View {
    
    @State var menuOpen: Bool = false
    
    var body: some View {
        
        
        ZStack(alignment: .top, content: {
           
            if !self.menuOpen {
                HStack {

                    Button(action: {
                        self.openMenu()
                    }, label: {
                        Text("Open")
                            .padding()
                        Spacer()
                    })
                }
                                
            }
            SideMenu(width: screenWidth-120,
                     isOpen: self.menuOpen,
                     menuClose: self.openMenu)
        })
        .navigationTitle("Side Menu")
        .navigationBarTitleDisplayMode(.inline)
        
    }
    
    func openMenu() {
        self.menuOpen.toggle()
    }
}

struct SideMenuView_Previews: PreviewProvider {
    static var previews: some View {
        SideMenuView()
    }
}
