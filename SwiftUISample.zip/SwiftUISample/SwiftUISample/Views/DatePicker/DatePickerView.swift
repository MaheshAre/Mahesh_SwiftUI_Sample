//
//  DatePickerView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/2/21.
//

import SwiftUI

struct DatePickerView: View {
    
    @State var selectedDate: String = ""
    
    var body: some View {
        
        VStack {
            
            Text("\(self.selectedDate)")
                .font(.title2)
            
            Button(action: {
                
                RPicker.selectDate(title: "DatePicker", cancelText: "Cancel", doneText: "Done", datePickerMode: .date, selectedDate: Date(), minDate: nil, maxDate: nil, style: .Wheel) { (date) in
                    
                    print(date)
                    self.selectedDate = date.toString(Date: nil, InputFormat: nil, OutPutFormat: .ddMMyyyy)
                    print(self.selectedDate)
                }
            }
            , label: {
                Text("Select Date")
                    .font(.title2)
            })
            .padding(.top, 20)
            
        }
        .navigationTitle("DatePicker")
        
        
    }
}

struct DatePickerView_Previews: PreviewProvider {
    static var previews: some View {
        DatePickerView(selectedDate: "\(Date())")
    }
}
