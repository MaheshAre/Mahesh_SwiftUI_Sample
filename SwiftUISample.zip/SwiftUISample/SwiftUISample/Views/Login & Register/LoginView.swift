//
//  LoginView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/12/21.
//

import SwiftUI

struct LoginView: View {
    
    @State var isShowPassword = false
    
    @State var isNavigatingHome = false
    @ObservedObject var vmLogin = VMLogin()
    
    @State var enumComingFrom: Enum_CommingFromView
    @State var isShowBackBtn = false
    
    
                                
    var body: some View {
        
//        NavigationView {
            
            VStack(alignment: .center, spacing: 15, content: {
                
                
                CustomTextField(PlaceHolder: "Custom TextField", BindingString: self.$vmLogin.params.email)
                    
                
                ZStack(alignment: Alignment(horizontal: .trailing, vertical: .center), content: {
                    
                    CustomSecureTextField(PlaceHolder: "Password", BindingString: self.$vmLogin.params.password, RightPadding: 50)
                    Button("   ") {
                        withAnimation() {
                            self.isShowPassword.toggle()
                            self.endEditing()
                        }

                    }
                    .padding()
                    .background(self.isShowPassword ? Image("icon_show") : Image("icon_hide"))
                    
                })
                
                if self.isShowPassword {
                    Text("Password: \(self.vmLogin.params.password)")
                }else {
                    Text("")
                }
                
                //MARK:- Login Button
                
                LoginBtnView(isNavigatingHome: self.isNavigatingHome, vmLogin: self.vmLogin, enumComingFrom: self.enumComingFrom)
                
            })
            .frame(maxWidth: screenWidth-30, maxHeight: .infinity, alignment: .top)
            .navigationTitle(self.enumComingFrom == Enum_CommingFromView.loginView ? "Login".localized : "Registration".localized)
            .padding()
            .navigationBarBackButtonHidden(self.isShowBackBtn)
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        
        LoginView(enumComingFrom: .loginView)
        
    }
}

struct LoginBtnView: View {
    
    @State var isNavigatingHome = false
    @ObservedObject var vmLogin = VMLogin()
    @State var enumComingFrom: Enum_CommingFromView
        
    var body: some View {
        
        NavigationLink(
            destination: HomeView(vmLogin: self.vmLogin, enumCommingFrom: Enum_CommingFromView.loginView, isShowBackBtn: true),
            isActive: self.$isNavigatingHome) { EmptyView() }
        
        Button(action: {
            
            self.endEditing()
            
            if self.isValideParams() {
                
                if self.enumComingFrom == .loginView {
                    
                    self.vmLogin.serivce_login(onCompletion: { isSuccess,errorMsg  in
                        if let error = errorMsg {
                            
                            CustomAlertController.showAlertController(message: error, actionTitle: "Ok")
                            
                        }
                        if isSuccess {
                            self.isNavigatingHome = true
                        }
                    })
                }else {
                    
                    self.vmLogin.service_registration { (isSuccess, error) in
                        if let error = error {
                            CustomAlertController.showAlertController(message: error, actionTitle: "Ok")
                        }
                        if isSuccess {
                            self.isNavigatingHome = true
                        }
                    }
                }
                
            }
            
        }, label: {
            Text("Login".localized)
        })
        .defaultStyle()
        .padding(.top, 5)
        .onAppear() {
            
            remove_userdeaultsData()
        }
        
    }
    
    func isValideParams() -> Bool {
        
        var boolValue = true
                
        if self.vmLogin.params.email.isValid_Email() == false {
            CustomToast.showToast(Message: "Please enter valid Email-Id")
            boolValue = false
        }else if self.vmLogin.params.password.isValid_TF(count: 6) == false {
//            self.isPasswordToast = true
            
            CustomToast.showToast(Message: "Please enter valid Password")
            
            boolValue = false
        }
        
        return boolValue
    }
}
