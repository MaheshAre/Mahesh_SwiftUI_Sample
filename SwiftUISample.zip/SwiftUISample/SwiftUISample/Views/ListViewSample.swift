//
//  ListView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/16/21.
//

import SwiftUI
//import SwiftUIRefresh

struct ListViewSample: View {
    
    @State var emp_array = [ModelEmp(id: 100, name: "ABC", age: 20),
                     ModelEmp(id: 101, name: "DEF", age: 21),
                     ModelEmp(id: 102, name: "GHI", age: 22),
                     ModelEmp(id: 103, name: "JKL", age: 20),
                     ModelEmp(id: 104, name: "MNO", age: 21),
                     ModelEmp(id: 105, name: "PQR", age: 22),
                     ModelEmp(id: 106, name: "STU", age: 20),
                     ModelEmp(id: 107, name: "VWX", age: 21),
                     ModelEmp(id: 108, name: "YZ", age: 22),
                     ModelEmp(id: 109, name: "abc", age: 20),
                     ModelEmp(id: 110, name: "def", age: 21),
                     ModelEmp(id: 111, name: "ghi", age: 22),
                     ModelEmp(id: 112, name: "jkl", age: 20),
                     ModelEmp(id: 113, name: "mno", age: 21),
                     ModelEmp(id: 114, name: "pqr", age: 22),
                     ModelEmp(id: 115, name: "stu", age: 20),
                     ModelEmp(id: 116, name: "vwx", age: 21),
                     ModelEmp(id: 117, name: "yz", age: 22),
                     ModelEmp(id: 118, name: "ABC", age: 20),
                     ModelEmp(id: 119, name: "DEF", age: 21),
                     ModelEmp(id: 120, name: "GHI", age: 22)]
        
    @State var isRefresh = false
    
    //    init() {
    //         UITableView.appearance().separatorStyle = .none
    //         UITableViewCell.appearance().backgroundColor = UIColor(Color.red)
    //         UITableView.appearance().backgroundColor = UIColor(Color.red)
    //      }
    
    var body: some View {
        
        
        List(emp_array, id: \.id) { emp in
            
            NavigationLink(
                destination: ListDetailsView(emp: emp),
                label: {
                    
                    VStack(alignment: .leading, spacing: 10, content: {
                        
                        HStack {
                            Text("Emp ID: ".localized).bold()
                                .font(.system(size: 20))
                            Text("\(emp.id!)")
                        }
                        
                        HStack {
                            Text("Name: ".localized).bold()
                                .font(.system(size: 20))
                            Text(emp.name!)
                            
                        }
                    })
                    
                })
            
        }
        .pullToRefresh(isShowing: self.$isRefresh, onRefresh: {
                        
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0) {
                self.emp_array.reverse()
                self.isRefresh = false
            }
            
        })
        .animation(.easeInOut)
        .navigationBarTitle("List Screen".localized)
        .navigationBarTitleDisplayMode(.inline)
        .listRowBackground(Color.green)
        .listSeparatorStyle(style: .none, verticalIndicator: false)
        .padding(.top, 10)
        
//                .animation(.interactiveSpring(response: 1, dampingFraction: 1, blendDuration: 1))
        
    }
}


struct ListViewSample_Previews: PreviewProvider {
    static var previews: some View {
        ListViewSample()
    }
}
