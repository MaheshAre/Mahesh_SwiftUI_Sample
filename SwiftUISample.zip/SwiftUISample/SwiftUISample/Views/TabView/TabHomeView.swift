//
//  TabHomeView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/2/21.
//

import SwiftUI

struct TabHomeView: View {
    var body: some View {
        
        Text("Welcome to TabView Home")
            .navigationTitle("Home TabView")        
    }
}

struct TabHomeView_Previews: PreviewProvider {
    static var previews: some View {
        TabHomeView()
    }
}
