//
//  TabViewSample.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/2/21.
//

import SwiftUI

struct TabViewSample: View {
    
    @State var selectedIndex = 0
    
    var body: some View {
        
        
        TabView(selection: self.$selectedIndex)  {
            
            NavigationView {
                TabHomeView()
            }
            .tabItem {
                Image(systemName: "homekit")
                Text("Home")
            }
            .tag(0)
            .navigationBarHidden(true)
            
            NavigationView {
                LoginView(enumComingFrom: .loginView)
//                    .navigationTitle("LoginVuew")
            }
            .tabItem {
                Image(systemName: "touchid")
                Text("Login")
            }
            .tag(1)
            .navigationBarHidden(true)
        }
        .accentColor(.red)
//        .tabViewStyle(PageTabViewStyle())
//                .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
        
        
        /*
        
        TabView {
            NavigationView {
                TabHomeView()
            }
            .tabItem {
                Image(systemName: "homekit")
                Text("Home")
            }
            .tag(1)
            .navigationBarHidden(true)
            
            
            NavigationView {
                LoginView(enumComingFrom: .loginView)
            }
            .tabItem {
                Image(systemName: "touchid")
                Text("Login")
            }
            .tag(2)
            .navigationBarHidden(true)
            
        }
        .accentColor(.red)
        */
        
    }
}

struct TabViewSample_Previews: PreviewProvider {
    static var previews: some View {
        TabViewSample()
    }
}
