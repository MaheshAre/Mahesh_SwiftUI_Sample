//
//  ListDetailsView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/16/21.
//

import SwiftUI

struct ListDetailsView: View {
    
    var emp: ModelEmp?
    
    var body: some View {
        
        VStack(alignment:.leading, spacing: 10, content: {
            
            HStack {
                Text("Emp ID: ").bold()
                    .font(.system(size: 20))
                Text("\(self.emp?.id ?? 0)")
            }
            
            HStack {
                Text("Name: ").bold()
                    .font(.system(size: 20))
                Text(self.emp!.name!)
                
            }
            
            HStack {
                Text("Age: ").bold()
                    .font(.system(size: 20))
                Text("\(self.emp?.age ?? 0)")
                
            }
        })
        .frame(minWidth: 100, idealWidth: 100, maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, minHeight: 100, idealHeight: 100, maxHeight: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .top)
        .padding(20)
//        .navigationTitle("List Deatils Screen")
        .navigationBarTitle("List Deatils Screen")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ListDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        ListDetailsView(emp: ModelEmp(id: 1, name: "A", age: 20))
    }
}
