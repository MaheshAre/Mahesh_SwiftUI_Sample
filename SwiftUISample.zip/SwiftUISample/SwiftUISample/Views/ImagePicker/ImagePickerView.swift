//
//  ImagePickerView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/8/21.
//

import SwiftUI
import UIKit

struct ImagePickerView: View {
    
    @State private var selectedImage: UIImage?
    @Environment(\.viewController) private var viewControllerHolder: UIViewController?
    
    var body: some View {
        VStack {
            Image(uiImage: self.selectedImage ?? UIImage())
                .set_ImageProperties(ContentMode: .fill, Width: 150, Height: 150, Corner: 15)
            
            Button(action: {
                
                ImagePickerAlertController.showAlertActionSheet(title: "Select Mode", message: "") { (sourceType, isCancelled) in
                    
                    if isCancelled == false {
                        
                        self.viewControllerHolder?.present(style: .popover, builder: {
                            
                            ImagePicker(sourceType: sourceType, onImagePicked: { image in
                                self.selectedImage = image
                            })
                        })
                        
                    }
                    
                }
                
                
            }, label: {
                Text("Select Image")
                    .font(.title)
                    .padding()
            })
            
        }
        .navigationTitle("ImagePicker")
    }
    
}

struct ImagePickerView_Previews: PreviewProvider {
    
    static var previews: some View {
        ImagePickerView()
    }
}

