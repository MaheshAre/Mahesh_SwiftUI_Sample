//
//  ContentView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/12/21.
//

import SwiftUI
import UIKit


struct ContentView: View {
    
    @State var tabBar: UITabBar? = nil
    @State var openMenu = true
        
    var body: some View {
        
        NavigationView {
            
            ScrollView(.vertical, showsIndicators: false, content: {
                
                ContentViewSetUp()
            })
            .navigationTitle("Content View".localized)
            .transition(.asymmetric(insertion: .opacity, removal: .scale))
            .padding()
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing, content: {
                                                        
                    CustomUIButton(title: "Language", fontSize: 15, foregroundColor: .white) { (btn) in

                        let languagesArray = Enum_languages.get_languagesStrArray()

                        FTPopoverClass.showPopover(Sender: btn, Width: 150, DataArray: languagesArray, ImagesArray: nil) { (selectedIndex) in

                            let selectedLanguage = Enum_languages.getLanguageByIndex(Index: selectedIndex)
                            
                            if Bundle.getCurrentLanguage() != selectedLanguage {
                                CustomAlertController.showAlertController(title: "Language Alert!", message: "Please reopen the app for language changing", actionTitle: "Ok") { (action) in

                                    Bundle.setLanguage(selectedLanguage)
                                        exit(0)
                                }
                            }

                        }
                    }

                })
            }
            
//            .animation(.interactiveSpring(response: 1, dampingFraction: 1, blendDuration: 1))
//            .animation(.interpolatingSpring(stiffness: 3, damping: 3))
            
        }
        .navigationBarHidden(true)
        .background(TabBarAccessor { tabbar in   // << here !!
            self.tabBar = tabbar
            self.tabBar?.isHidden = true
            
        })
        .onAppear() {

        }
        
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ContentViewSetUp: View {
        
    var body: some View {
        
                
        VStack(alignment: .center, spacing: 15, content: {
            
            Group {
                
                //MARK:- Login Link
                NavigationButton(
                    action: {
                        //                        print("tapped!")
                    },
                    destination: { LoginView(enumComingFrom: Enum_CommingFromView.loginView) },
                    label: {
                        Text("Login".localized)
                    })
                    .default_ButtonStyle()
                
                //MARK:- ListView Link
                NavigationButton(
                    action: {
                        //                        print("tapped!")
                    },
                    destination: { ListViewSample() },
                    label: {
                        Text("List Sample".localized)
                    })
                    .default_ButtonStyle()
                
                //MARK:- GET Request
                NavigationButton(
                    action: {  },
                    destination: { GetRequestView() },
                    label: {
                        Text("Get Request")
                    })
                    .default_ButtonStyle()
                
                //MARK:- POST Request
                NavigationButton(
                    action: {  },
                    destination: { PostRequestView() },
                    label: {
                        Text("Post Request")
                    })
                    .default_ButtonStyle()
                
                //MARK:- Regitsration Request
                NavigationButton(
                    action: { },
                    destination: { LoginView(enumComingFrom: Enum_CommingFromView.registrationView) },
                    label: {
                        Text("Registration")
                    })
                    .default_ButtonStyle()
            }
            
            Group {
                
                //MARK:- CollectionView
                NavigationButton(
                    action: { },
                    destination: { CollectionView() },
                    label: {
                        Text("CollectionView")
                    })
                    .default_ButtonStyle()
                
                //MARK:- GridView With Service
                NavigationButton(
                    action: { },
                    destination: { GridWithService() },
                    label: {
                        Text("GridView")
                    })
                    .default_ButtonStyle()
                
                //MARK:- TabView
                
                NavigationButton(
                    action: { },
                    destination: { TabViewSample() },
                    label: {
                        Text("TabView")
                    })
                    .default_ButtonStyle()
                
                //MARK:- DatePicker
                
                NavigationButton(
                    action: { },
                    destination: { DatePickerView() },
                    label: {
                        Text("DatePicker")
                    })
                    .default_ButtonStyle()
                
                //MARK:- DatePicker
                
                NavigationButton(
                    action: { },
                    destination: { ImagePickerView() },
                    label: {
                        Text("ImagePicker")
                    })
                    .default_ButtonStyle()
                
            }
            
            Group {
                
                //MARK:- SideMenu
                NavigationButton(action: { }, destination: { SideMenuView() }, label: {
                    Text("SideMenu")
                })
                .default_ButtonStyle()
                
                //MARK:- Current Location
                NavigationButton(action: { }, destination: { LocationsView() }, label: {
                    Text("CurrentLocation")
                })
                .default_ButtonStyle()
                
                //MARK:- Location Picker
                NavigationButton(action: { }, destination: { LocationPickerView() }, label: {
                    Text("LocationPicker")
                })
                .default_ButtonStyle()
                
                //MARK:- Share
                Button(action: {
                    self.showShareOptions(ShareMesage: "WelCome to Share")
                }, label: {
                    Text("Share")
                })
                .default_ButtonStyle()
                
                //MARK:- Open Safari
                
                Button(action: {
                    self.openSafari(URLStr: "https://www.apple.com")
                    
                }, label: {
                    Text("Open Safari")
                })
                .default_ButtonStyle()
                
            }
            
            Group {
                
                //MARK:- DropDown
                NavigationButton(action: { }, destination: { DropDownView() }, label: {
                    Text("DropDown")
                })
                .default_ButtonStyle()
            }
                
                        
        })
        .onAppear() {
//            self.displayDates()
            print(Enum_languages.allLanguages)
            
        }
                   
    }
    
    func displayDates() -> some View {
        
        self.Perform {
            
            let currentDate = Date()//getCurrentDate()
//            print("Current Date -> \(currentDate)")
            
            let dateStr = currentDate.toString()
//            print("Date in String -> \(dateStr)")
            
            
            let date = dateStr.toDate(InputFormat: .yyyymmddHHmmss, OutPutFormat: .yyyymmddHHmmss)
            print("Coverted Date -> \(date)")
            
            
        }
    }

    
}
