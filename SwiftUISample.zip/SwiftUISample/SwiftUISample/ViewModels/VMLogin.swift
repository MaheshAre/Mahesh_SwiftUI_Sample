//
//  VMLogin.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/22/21.
//

import Foundation
import SwiftUI

class VMLogin: ObservableObject {
    
    @Published var vmLogin: ModelLogin = ModelLogin()
    
    @Published var params: LoginParams = LoginParams()
 
    init() {
        
    }
    
    func serivce_login(onCompletion: @escaping(_ isFinished: Bool, _ errorMsg: String?)->Void) {
        
        let params = ["email": self.params.email, "password": self.params.password]
//        let params = ["email": "eve.holt@reqres.in", "password": "cityslicka"]
        
//        print(params)
                
        NetworkManager.shared.createRequest(apiStr: .login, method: .post, params: params, headerContentType: .applicationjson, isShowLoader: true) { (response, error) in
            
            if let error = error {
                self.vmLogin.message = error
                _ = Alert(title: Text("Error"), message: Text("\(error)"), dismissButton: nil)
                onCompletion(false, error)
            }else {
                do {
                    let jsonData = try JSONDecoder().decode(ModelLogin.self, from: response!.data!)
                    self.vmLogin = jsonData
                    self.vmLogin.message = self.vmLogin.token ?? ""
                    
                    user_defaults.setValue(self.vmLogin.token, forKey: Enum_UserData.token.rawValue)
                    user_defaults.setValue(true, forKey: Enum_UserData.isLoggedIn.rawValue)
                    
                    print(jsonData)
                    
                    onCompletion(true, nil)
                    
                }catch {
                    print(error)
                    onCompletion(false, error.localizedDescription)
                }
            }
                        
        }
        
    }
    
    func service_registration(onCompletion: @escaping(_ isFinished: Bool, _ errorMsg: String?)->Void) {
        
        let params = ["email": self.params.email, "password": self.params.password]
        
        NetworkManager.shared.createRequest(apiStr: .register, method: .post, params: params, isShowLoader: true) { (response, error) in
            
            if let error = error {
                self.vmLogin.message = error
                onCompletion(false, error)
            }else {
                do {
                    let jsonData = try JSONDecoder().decode(ModelLogin.self, from: response!.data!)
                    self.vmLogin = jsonData
                    
                    user_defaults.setValue(self.vmLogin.token, forKey: Enum_UserData.token.rawValue)
                    user_defaults.setValue(true, forKey: Enum_UserData.isLoggedIn.rawValue)
                    
                    onCompletion(true, nil)
                }catch {
                    print(error)
                    onCompletion(false, error.localizedDescription)
                }
            }
        }
        
    }
}

struct LoginParams {
    
    var email = "eve.holt@reqres.in"
    var password = "123456789"
}

enum Enum_UserData: String {
    
    case token
    case isLoggedIn
}
