//
//  VMPostSample.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/19/21.
//

import Foundation
import SwiftUI

class VMPostSample: ObservableObject {
    
    var id = UUID()
    
    @Published var data: ModelPostSample = ModelPostSample()
    
    init() {
        self.servicePostSample()
    }
    
    func servicePostSample() {
        
        let params = ["name": "morpheus",
                      "job": "leader"]
        NetworkManager.shared.createRequest(apiStr: .getUsers, method: .post, params: params, isShowLoader: true) { (response, error) in
            
            if let error = error {
                _ = Alert(title: Text("Error"), message: Text("\(error)"), dismissButton: nil)
            }else {
                do {
                    let jsonData = try JSONDecoder().decode(ModelPostSample.self, from: response!.data!)
                    self.data = jsonData
                }catch {
                    print(error)
                }
            }
        }
    }
}
