//
//  VMGet.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/17/21.
//

import Foundation
import SwiftUI


class VMGet: ObservableObject {
    
    @Published var data: [UserData] = []
    
    var id: UUID?
    
    func servicGETRequest() {
        
        NetworkManager.shared.createRequest(apiStr: .getUsers, method: .get, params: nil) { (response, error) in
            
            if let error = error {
                _ = Alert(title: Text("Error"), message: Text(error), dismissButton: .cancel())
            }else {
                do {
                    let jsonData = try JSONDecoder().decode(ModelGetSample.self, from: response!.data!)
//                    self.totData = jsonData
                    self.data = jsonData.data!
                                        
                } catch {
                    
                }
                
            }
        }
    }
}
