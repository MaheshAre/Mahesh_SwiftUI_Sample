//
//  SwiftUISampleApp.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/12/21.
//

import SwiftUI
import UIKit
//import LanguageManager_iOS

@main
struct SwiftUISampleApp: App {
                            
    init() {
        
//        if let languageStr = user_defaults.value(forKey: languageKey) as? String {
//
//            let language = Languages(rawValue: languageStr)
//            LanguageManager.shared.defaultLanguage = language!
//            LanguageManager.shared.setLanguage(language: language!)
//        }else {
//            LanguageManager.shared.defaultLanguage = .ar
//            LanguageManager.shared.setLanguage(language: .ar, for: nil, viewControllerFactory: nil, animation: nil)
//        }

        print(Bundle.getCurrentLanguage())
                
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        
        //        sleep(UInt32(2))
    }
    
    var body: some Scene {
        WindowGroup {
            
            NavigationView {
                
                ContentView()
                
                if let isLoggedIn = user_defaults.value(forKey: Enum_UserData.isLoggedIn.rawValue) as? Bool {
                    if isLoggedIn {
                        ContentView()
                    }else {
                        LoginView(enumComingFrom: .loginView)
                    }
                    
                }else {
                    LoginView(enumComingFrom: .loginView)
                }
                
            }
            .onAppear(){
                self.setStatusBarColor(BGColor: .gray)
                self.setNavigationBar(BGColor: .gray, TitleColor: .white, TintColor: .white)
            }
        }
        
    }
}
