////
////  Localizable.swift
////  SwiftUISample
////
////  Created by IC-MAC004 on 3/22/21.

import Foundation
import UIKit
import SwiftUI

/*
 Usage:
 
 In .app File in init() func put -> print(Bundle.getCurrentLanguage())
 
 To Set Language:
 
 In Button Action put -> Bundle.setLanguage(.arabic)
 
 
 */


private let Key_Language = "LanguageKey"
private let Key_AppleTextDirection = "AppleTextDirection"
private let Key_NSForceRightToLeftWritingDirection = "NSForceRightToLeftWritingDirection"

private var kBundleKey: UInt8 = 0

private class BundleEx: Bundle {
    
    override func localizedString(forKey key: String, value: String?, table tableName: String?) -> String {
        if let bundle = objc_getAssociatedObject(self, &kBundleKey) {
            return (bundle as! Bundle).localizedString(forKey: key, value: value, table: tableName)
        }
        return super.localizedString(forKey: key, value: value, table: tableName)
    }
    
}

private var kBundleUIKitKey: UInt8 = 0

private class BundleUIKitEx: Bundle {
    
    override func localizedString(forKey key: String, value: String?, table tableName: String?) -> String {
        if let bundle = objc_getAssociatedObject(self, &kBundleUIKitKey) {
            return (bundle as! Bundle).localizedString(forKey: key, value: value, table: tableName)
        }
        return super.localizedString(forKey: key, value: value, table: tableName)
    }
    
}

extension Bundle {
    
    static let once: Void = {
        object_setClass(Bundle.main, type(of: BundleEx()))
        object_setClass(Bundle(identifier:"com.apple.UIKit"), type(of: BundleUIKitEx()))
    }()
    
    class func setLanguage (_ language: Enum_languages) {
        
        Bundle.once
        let isLanguageRTL = Bundle.isLanguageRTL(language.rawValue)
        if (isLanguageRTL) {
            UIView.appearance().semanticContentAttribute = .forceRightToLeft
        } else {
            UIView.appearance().semanticContentAttribute = .forceLeftToRight
        }
        
        UserDefaults.standard.set(isLanguageRTL, forKey: Key_AppleTextDirection)
        UserDefaults.standard.set(isLanguageRTL, forKey: Key_NSForceRightToLeftWritingDirection)
        
        let value = Bundle.init(path: (Bundle.main.path(forResource: language.rawValue, ofType: "lproj"))!)
        objc_setAssociatedObject(Bundle.main, &kBundleKey, value, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        
        if let uiKitBundle = Bundle(identifier: "com.apple.UIKit") {
            var valueUIKit: Bundle? = nil
            if let path = uiKitBundle.path(forResource: language.rawValue, ofType: "lproj") {
                valueUIKit = Bundle(path: path)
            }
            objc_setAssociatedObject(uiKitBundle, &kBundleUIKitKey, valueUIKit, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        }
        
        UserDefaults.standard.setValue(language.rawValue, forKey: Key_Language)
        UserDefaults.standard.synchronize()
        
    }
    
    static func isLanguageRTL(_ languageCode: String?) -> Bool {
        return (languageCode != nil && Locale.characterDirection(forLanguage: languageCode!) == .rightToLeft)
    }
    
    static func getCurrentLanguage() -> Enum_languages {
        
        if let selectedLanguage = UserDefaults.standard.value(forKey: Key_Language) as? String {
            
            let language = Enum_languages(rawValue: selectedLanguage)!
            
            self.setLanguage(language)
            
            return language
        }else {
            
//            self.setLanguage(.english)
            
            return .english
        }
    }
    
}

extension String {
    
    var localized: String {
        return NSLocalizedString(self, comment: "\(self)_comment")
    }
    
    func localized(_ args: CVarArg...) -> String {
        return String(format: localized, args)
    }
}

enum Enum_languages: String {
    
    case english = "en"
    case arabic = "ar"
//    case ukrainian = "uk"
    
    static let allLanguages = [english, arabic]
    
    static func get_languagesStrArray() -> [String] {
        
        var languagesArray = [String]()
        for lang in Enum_languages.allLanguages {
            languagesArray.append("\(lang)".firstUppercased)
        }
        
        return languagesArray
    }
    
    static func getLanguageByIndex(Index index: Int) -> Enum_languages {
        return Enum_languages.allLanguages[index]
    }
        
}

struct GetAllLanguagesList {
    
    static var get_LanguagesArray = Enum_languages.allLanguages
}
