//
//  Constants.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/26/21.
//

import Foundation
import SwiftUI


let appName = ""
let appStoreID = ""
let screenWidth = UIScreen.main.bounds.width
let screenHeight = UIScreen.main.bounds.height


func getBundleID() -> String {
    return Bundle.main.bundleIdentifier ?? "BundleID"
}

func getAppVersion() -> String {
    
    var appVersion = "1.0"
    if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
        appVersion = version
    }
    
    return appVersion
}

func getBuildNumber() -> String {
    
    var buildNumber = "1.0"
    if let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String {
        buildNumber = build
    }
    
    return buildNumber
}

func versionCompare(InstalledVersion: String, AppstoreVersion appStoreVersion: String) -> ComparisonResult {
    
    let result = InstalledVersion.compare(appStoreVersion, options: .numeric)
//        print(result.rawValue)
    return result
}

func getAppstoreURL(AppStoreID appStoreID: String = "360466413") -> URL {
    
    var url = URL(string: "itms-apps://apple.com/app/")!
    if let urlFinale = URL(string: "itms-apps://apple.com/app/id\(appStoreID)") {
        url = urlFinale
    }
    
    return url
}

//MARK:- Targets

var currentTarget: Enum_Targets = Enum_Targets.Capium

func getTargetName() {
    
    var targetName = ""
    
    if let target = Bundle.main.infoDictionary?["CFBundleExecutable"] as? String {
        targetName = target
    }
    
    currentTarget = Enum_Targets(rawValue: targetName) ?? .Capium
}

enum Enum_Targets: String {
    
    case Capium
    case Xpert
    
}
