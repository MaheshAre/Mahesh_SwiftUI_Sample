//
//  String+Extension.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/25/21.
//

import Foundation
import SwiftUI
import UIKit

//MARK:- String Extensions

extension String {
    
    /// String to Text Conversion
   ///
   func toText() -> Text {
       return Text(self)
   }
    /// Returns TRUE when they are equal else Returns FALSE
    func compareIngoreCase(SecondStr secStr: String) -> Bool {
        if(self.caseInsensitiveCompare(secStr) == .orderedSame){
            return true
        }else {
            return false
        }
    }
}

extension StringProtocol {
    
    /// Returns with FirstLetter Capital
   ///
    var firstUppercased: String { prefix(1).uppercased() + dropFirst() }
    /// Returns with FirstLetter Capital
   ///
    var firstCapitalized: String { prefix(1).capitalized + dropFirst() }
}
