//
//  Image+Extension.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/19/21.
//

import Foundation
import SwiftUI
import UIKit

//MARK:- Static Images

extension Image {
    
    static let img_placeHolder = Image("placeHolder")
}

//MARK:- Image Extensions
extension Image {
    
    func set_ImageProperties(ContentMode mode: ContentMode, Width width: CGFloat = .infinity, Height height: CGFloat = .infinity, Corner cRadius: CGFloat = .nan) -> some View {
        return self
            .resizable()
            .aspectRatio(contentMode: mode)
            .frame(width: width, height: height, alignment: .center)
            .cornerRadius(cRadius)
    }
}


//MARK:- UIImage Extensions

extension UIImage {
    
    /// Convert UIImage to Image
    func toImage() -> Image {
        return Image(uiImage: self)
    }
  
    /// convert image to base64 string
    func toBase64(format: Enum_ImageFormat) -> String {
        
        var imageData: NSData
        switch format {
        case .PNG: imageData = self.pngData()! as NSData
        case .JPEG(let compression): imageData = self.jpegData(compressionQuality: compression)! as NSData
            
        }
        return imageData.base64EncodedString(options: .lineLength64Characters)
    }

  ///convert string to image
  func base64ToImage(toImage strEncodeData: String) -> UIImage {
    
    let dataDecoded  = NSData(base64Encoded: strEncodeData, options: NSData.Base64DecodingOptions.ignoreUnknownCharacters)!
    let image = UIImage(data: dataDecoded as Data)
    return image!
  }


  //function for resize image
  func resizeImage(targetSize: CGSize) -> UIImage {
    let size = self.size

    let widthRatio  = targetSize.width  / self.size.width
    let heightRatio = targetSize.height / self.size.height

    // Figure out what our orientation is, and use that to form the rectangle
    var newSize: CGSize
    if(widthRatio > heightRatio) {
      newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
    } else {
      //                        newSize = size
      newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
    }

    // This is the rect that we've calculated out and this is what is actually used below
    let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)

    // Actually do the resizing to the rect using the ImageContext stuff
    UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
    self.draw(in: rect)
    let newImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()

    return newImage!
  }
}

enum Enum_JPEGQuality: CGFloat {
    
    case lowest  = 0
    case low     = 0.25
    case medium  = 0.5
    case high    = 0.75
    case highest = 1
}

public enum Enum_ImageFormat {
  case PNG
  case JPEG(CGFloat)
}

