//
//  Color+Extension.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/26/21.
//

import Foundation
import SwiftUI

extension Color {
    
    static var systemRed = UIColor.red
    
    ///get new color from rgb value
    func getColorFromRGB(Red red:CGFloat , Green green:CGFloat, Blue blue:CGFloat, withAlpha alpha:CGFloat) -> UIColor {
        let color = UIColor(red: red/255.0, green: green/255.0, blue: blue/255.0, alpha: alpha)
        return color
    }
    
    ///return color from comma separated string of RGB paramater
    init(rgbString :String, alpha:CGFloat = 1.0) {
        let arrColor = rgbString.components(separatedBy: ",")
        let red = Double(truncating: NumberFormatter().number(from: arrColor[0])!)
        let green = Double(truncating: NumberFormatter().number(from: arrColor[1])!)
        let blue = Double(truncating: NumberFormatter().number(from: arrColor[2])!)
        
        self.init(red: red/255.0, green: green/255.0, blue: blue/255.0, opacity: Double(alpha))
    }

    ///return color from hexadecimal value E.g: let color2 = UIColor(rgbHexaValue: 0xFFFFFFFF)
      //let color2 = UIColor(rgbHexaValue: 0xFFFFFFFF)
    init(rgbHexaValue: Int, alpha: CGFloat = 1.0) {
        
        self.init(red:  Double(CGFloat((rgbHexaValue >> 16) & 0xFF)), green: Double(CGFloat((rgbHexaValue >> 8) & 0xFF)), blue: Double(CGFloat(rgbHexaValue & 0xFF)), opacity: Double(alpha))
    }
}

extension UIColor {
    
    func toColor() -> Color {
        
        return Color(self)
    }
}
