//
//  PickLocation_MapView.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/12/21.
//

import SwiftUI
import MapKit
import CoreLocation
import UIKit
import Combine

/*
 Usage:
 
 @ObservedObject var locationManager = LocationManager()
 
 
 
 NavigationButton(destination: {
 
 PickLocation_MapView(locationManager: self.locationManager)
 }, label: {
 Text("Select Location From Map")
 })
 .default_ButtonStyle()
 .padding()
 
 Text(self.locationManager.addressStruct?.formattedAddress ?? "Selected Address")
 Text(self.locationManager.coordinate?.coordinateStr ?? "Coordinates")
 
 */

struct PickLocation_MapView: View {
    
    @Environment(\.presentationMode) private var presentationMode
    // self.presentationMode.wrappedValue.dismiss()
    
    @ObservedObject var locationManager: LocationManager = LocationManager()
    
    //Tap on Current Locatiuon Button purpose
    @ObservedObject var currentLocationManager: LocationManager = LocationManager(IsUpdateCurrentLocation: true)
    
    @State var selectedLocation = ""
    
    var body: some View {
        
        ZStack {
            
            MapView(locationManager: self.locationManager)
            
            VStack {
                
                HStack {
                    ZStack {
                        HStack {
                            
                            //                        Image(uiImage: UIImage(named: "search")!)
                            Image.icon_search
                                .set_ImageProperties(ContentMode: .fit, Width: 20, Height: 20)
                            
                            TextField("Search Location", text: self.$selectedLocation)
                                .disabled(true)
                        }
                        .setShadow(CornerRadius: 8, ShadowColor: nil, ShadowRadius: 1)
                        .padding(EdgeInsets(top: 5, leading: 15, bottom: 0, trailing: 15))
                        
                        NavigationButton(destination: {
    //                        MKLocalSearchCompleterExampleView(locationSearchService: LocationSearchService())
                            MKLocalSearchCompleterExampleView(locationService: LocationService(), locationManager: self.locationManager)
    //                        MKLocalSearchCompleterExampleView()
                        }, label: {
                            Text("")
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                        })
                    }
                    
                    
                }
                .frame(width: screenWidth, height: 60, alignment: .center)
                
                //            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button(action: {
                        
                        let locManager = self.currentLocationManager//LocationManager(IsUpdateCurrentLocation: true)
                        
                        self.locationManager.lat = locManager.lat
                        self.locationManager.long = locManager.long
                        self.locationManager.coordinate = locManager.coordinate
                        self.locationManager.addressStruct = locManager.addressStruct
                        
                    }, label: {
                        Image.icon_currentLocation
                            .set_ImageProperties(ContentMode: .fit, Width: 60, Height: 60, Corner: 0)
                            .clipShape(Circle())
                    })
                    
                }
                .padding(10)
                .padding(.bottom, -10)
                HStack {
                    Button("Done", action: {
                        self.presentationMode.wrappedValue.dismiss()
                    })
                    .frame(width: screenWidth-30, height: 45, alignment: .center)
                    .default_ButtonStyle()
                    .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 22)
                }
                .padding()
                //            }
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .onAppear() {
            
        }
        
    }
    
}

//struct PickLocation_MapView_Previews: PreviewProvider {
//    static var previews: some View {
//        PickLocation_MapView()
//    }
//}


struct MapView: UIViewRepresentable {
    
    @ObservedObject var locationManager: LocationManager // = LocationManager()
    
    var lat: Double {
        return self.locationManager.lat ?? 0.0
    }
    
    var lLong: Double {
        return self.locationManager.long ?? 0.0
    }
    
    var coordinate: CLLocationCoordinate2D {
        return self.locationManager.coordinate ?? CLLocationCoordinate2D(latitude: 0.0, longitude: 0.0)
    }
    
    let mapView = MKMapView()
    
    func makeUIView(context: Context) -> MKMapView {
        
        mapView.delegate = context.coordinator
        self.mapView.showsUserLocation = true
        
        self.mapView.removeAnnotations(self.mapView.annotations)
        
        return mapView
    }
    
    func updateUIView(_ view: MKMapView, context: Context) {
        
        // Initially Showing Current Location
        view.removeAnnotations(view  .annotations)
        
        DispatchQueue.main.async {
            let span = MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005) // 2.0
            let region = MKCoordinateRegion(center: self.coordinate, span: span)
            
            let customAnnotation = CustomAnnotation(Coordinates: self.coordinate, Title: self.locationManager.addressStruct?.name, SubTitle: self.locationManager.addressStruct?.formattedAddress, Icon: nil)
            
            view.addAnnotation(customAnnotation)
            view.setRegion(region, animated: true)
        }
    }
    
    func makeCoordinator() -> Coordinator {
        
        return Coordinator(self)
    }
    
    class Coordinator: NSObject, MKMapViewDelegate, UIGestureRecognizerDelegate {
        
        var parent: MapView
        var gRecognizer = UILongPressGestureRecognizer()//UITapGestureRecognizer()
        
        @ObservedObject var locationManager: LocationManager// = LocationManager()
        
        init(_ parent: MapView) {
            
            self.parent = parent
            self.locationManager = parent.locationManager
            super.init()
            
            self.gRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(tapHandler))
            self.gRecognizer.delegate = self
            self.parent.mapView.addGestureRecognizer(gRecognizer)
                                    
            DispatchQueue.main.async {
                
                self.parent.mapView.removeAnnotations(self.parent.mapView.annotations)
                
                let span = MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005) // 2.0
                let coordinates = self.locationManager.coordinate ?? CLLocationCoordinate2D(latitude: 100.0, longitude: 100.0)
                let region = MKCoordinateRegion(center: coordinates, span: span)
                
                let customAnnotation = CustomAnnotation(Coordinates: coordinates, Title: self.locationManager.addressStruct?.name, SubTitle: self.locationManager.addressStruct?.formattedAddress, Icon: nil)
                
                self.parent.mapView.addAnnotation(customAnnotation)
                self.parent.mapView.setRegion(region, animated: true)
            }
            
        }
        
        @objc func tapHandler(_ gesture: UITapGestureRecognizer) {
            
            // Remove Annotation
            self.parent.mapView.removeAnnotations(self.parent.mapView.annotations)
            
            // position on the screen, CGPoint
            let location = gRecognizer.location(in: self.parent.mapView)
            // position on the map, CLLocationCoordinate2D
            let coordinate = self.parent.mapView.convert(location, toCoordinateFrom: self.parent.mapView)
            
            LocationManager.convertLatLongToAddress(latitude: coordinate.latitude, longitude: coordinate.longitude, onCompletion: { (addressStruct) in
                
                self.locationManager.addressStruct = addressStruct
                self.locationManager.lat = addressStruct.latitude
                self.locationManager.long = addressStruct.longitude
                self.locationManager.coordinate = addressStruct.coordinate
                
                //                print(self.locationManager.coordinate as Any)
                //                print(self.locationManager.addressStruct?.formattedAddress as Any)
                
            })
            
            //            print(coordinate)
            
            let customAnnotation = CustomAnnotation(Coordinates: coordinate, Title: self.locationManager.addressStruct?.name, SubTitle: self.locationManager.addressStruct?.formattedAddress, Icon: nil)
            
            self.parent.mapView.addAnnotation(customAnnotation)
            
        }
        
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
                        
            if annotation.isKind(of: MKUserLocation.self) {  //Handle user location annotation..
                return nil  //Default is to let the system handle it.
            }
            
            if !annotation.isKind(of: CustomAnnotationView.self) {  //Handle non-ImageAnnotations..
                var pinAnnotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "DefaultPinView")
                if pinAnnotationView == nil {
                    pinAnnotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "DefaultPinView")
                }
                
                pinAnnotationView!.canShowCallout = true
                
                return pinAnnotationView
            }
            
            //Handle ImageAnnotations..
            var view: CustomAnnotationView? = mapView.dequeueReusableAnnotationView(withIdentifier: "imageAnnotation") as? CustomAnnotationView
            if view == nil {
                view = CustomAnnotationView(annotation: annotation, reuseIdentifier: "imageAnnotation")
            }
            
            let annotation = annotation as! CustomAnnotation
            view?.image = annotation.image
            view?.isSelected = true
            view?.annotation = annotation
            
            return view
        }
        
        
        func updateUIView(_ view: MKMapView, context: Context) {
            //If you changing the Map Annotation then you have to remove old Annotations
                        self.parent.mapView.removeAnnotations(self.parent.mapView.annotations)
            //assigning delegate
            view.delegate = context.coordinator
            //passing model array here
            //            view.addAnnotations(landmarks)
        }
    }
    
}

class CustomAnnotation : NSObject, MKAnnotation {
    
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    var image: UIImage?
    var colour: UIColor?
    
    override init() {
        self.coordinate = CLLocationCoordinate2D()
        self.title = nil
        self.subtitle = nil
        self.image = nil
        self.colour = UIColor.white
    }
    
    init(Coordinates coordinate: CLLocationCoordinate2D?, Title title: String?, SubTitle subTitle: String?, Icon icon: UIImage?) {
        
        self.coordinate = coordinate ?? CLLocationCoordinate2D(latitude: 0.0, longitude: 0.0)
        self.title = title ?? ""
        self.subtitle = subTitle ?? ""
        self.image = icon ?? UIImage(named: "locationPin")
        self.colour = UIColor.white
        
    }
}

class CustomAnnotationView: MKAnnotationView {
    
    private var imageView: UIImageView!
    
    override init(annotation: MKAnnotation?, reuseIdentifier: String?) {
        super.init(annotation: annotation, reuseIdentifier: reuseIdentifier)
        
        self.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        self.imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
        self.addSubview(self.imageView)
        self.imageView.layer.cornerRadius = 5.0
        self.imageView.layer.masksToBounds = true
    }
    
    override var image: UIImage? {
        get {
            return self.imageView.image
        }
        
        set {
            self.imageView.image = newValue
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
