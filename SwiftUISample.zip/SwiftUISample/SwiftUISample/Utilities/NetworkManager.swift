//
//  NetworkManager.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/15/21.
//

import Foundation
import Alamofire
import SwiftUI
import UIKit

struct NetworkManager {
    
    static let shared = NetworkManager()
    private init () { }
    
    func createRequest(apiStr: Enum_ApisMethods, method: HTTPMethod, params: [String: Any]?, headerContentType: Enum_HeaderContentTypes = .applicationjson, isShowLoader: Bool = true, onCompletion: @escaping (_ successResponse: AFDataResponse<Any>?, _ failureResponseString: String?)->Void) {
        
        if Connectivity.isConnectedToInternet() == false {
            
            NetworkAlertController.showAlertControllerForNetwork(title: "Internet Connection", message: "Please check your Internet Connection", actionTitle: "Try Again")
            return
        }
        
        if isShowLoader {
            SKActivityCustom.shared.showLoader(text: "Loading...")
        }
        
        let finalAPI = Domains().getBaseURL() + apiStr.rawValue
        let headers = CustomHeaders(ContentType: headerContentType)
        
//        print(finalAPI)
//        print(params ?? ["":""])
//        print(headers)
        
        AF.request(finalAPI, method: method, parameters: params, headers: headers).responseJSON { serviceResponse in
                        
            var statusCode = 0
            if let code = serviceResponse.response?.statusCode {
                statusCode = code
            }
                                                
            if let error = serviceResponse.error {
                
                switch error {
                
                case .invalidURL(url: let url):
                    print("Invalid URL ->", url)
                    break
                case .parameterEncodingFailed(let reason):
                    print("Parameter encoding failed: \(error.localizedDescription)")
                    print("Failure Reason: \(reason)")
                case .multipartEncodingFailed(let reason):
                    print("Multipart encoding failed: \(error.localizedDescription)")
                    print("Failure Reason: \(reason)")
                case .responseValidationFailed(let reason):
                    print("Response validation failed: \(error.localizedDescription)")
                    print("Failure Reason: \(reason)")
                    
                    switch reason {
                    case .dataFileNil, .dataFileReadFailed:
                        print("Downloaded file could not be read")
                    case .missingContentType(let acceptableContentTypes):
                        print("Content Type Missing: \(acceptableContentTypes)")
                    case .unacceptableContentType(let acceptableContentTypes, let responseContentType):
                        print("Response content type: \(responseContentType) was unacceptable: \(acceptableContentTypes)")
                    case .unacceptableStatusCode(let code):
                        print("Response status code was unacceptable: \(code)")
                    case .customValidationFailed(error: let error):
                        print("Error: \(error)")
                    }
                case .responseSerializationFailed(let reason):
                    print("Response serialization failed: \(error.localizedDescription)")
                    print("Failure Reason: \(reason)")
                // statusCode = 3840 ???? maybe..
                default:break
                }
                
                onCompletion(nil, error.localizedDescription)
                
            }
            
            
            if let value = serviceResponse.value as? NSDictionary {
                if let errorDescription = value["error_description"] as? String {
                    onCompletion(nil, errorDescription)
                }else {
                    
                    switch statusCode {
                    
                    case 200..<300:
//                        print("Success")
                        onCompletion(serviceResponse, nil)
                        break
                        
                    case 400..<402:
                        
                        if let message = value["Message"] as? String {
                            onCompletion(nil, message)
                        }else {
                            onCompletion(nil, "Bad Request")
                        }
                        
                    default:
                        print("Default")
                        onCompletion(nil, serviceResponse.error?.localizedDescription)
                    }
                }
            }
            
            SKActivityCustom.shared.hideLoader()
        }
        
    }
}


//MARK:- Internet check
class Connectivity {
    class func isConnectedToInternet() ->Bool {
        return NetworkReachabilityManager()!.isReachable
    }
}

class AlertController {
    static func msg(message: String, title: String = "") {
        let alertView = UIAlertController(title: title, message: message, preferredStyle: .alert)

        alertView.addAction(UIAlertAction(title: "Done", style: .default, handler: nil))
        
        UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController?.present(alertView, animated: true, completion: nil)

//        UIApplication.shared.keyWindow?.rootViewController?.present(alertView, animated: true, completion: nil)
    }
}

struct NetworkAlertController {

    static func showAlertControllerForNetwork(title: String = "", message: String, actionTitle: String) {
        
        let alertView = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: actionTitle, style: .default) { (action) in
            
            if Connectivity.isConnectedToInternet() == false {
                UIWindow.key?.rootViewController?.present(alertView, animated: true, completion: nil)
            }
            
        }
        alertView.addAction(action)
        UIWindow.key?.rootViewController?.present(alertView, animated: true, completion: nil)
//        UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController?.present(alertView, animated: true, completion: nil)

    }
}

extension UIWindow {
    static var key: UIWindow? {
        if #available(iOS 13, *) {
            return UIApplication.shared.windows.first { $0.isKeyWindow }
        } else {
            return UIApplication.shared.keyWindow
        }
    }
}

// application/x-www-form-urlencoded
// multipart/form-data

//MARK:- Headers
let ContentType = "Content-Type"
let Authorization = "Authorization"
var AccessToken = ""

func CustomHeaders(ContentType contentType: Enum_HeaderContentTypes = Enum_HeaderContentTypes.applicationjson) -> HTTPHeaders {

    return [ContentType : contentType.rawValue,
            Authorization:"Bearer \(AccessToken)"]
}

enum Enum_HeaderContentTypes: String {
    
    /// application/json
    case applicationjson = "application/json"
    
    /// multipart/form-data
    case multiPartFormData = "multipart/form-data"
    
    /// application/x-www-form-urlencoded
    case formurlencoded = "application/x-www-form-urlencoded"
    
}
