//
//  Extensions.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/15/21.
//

import Foundation
import SwiftUI


//MARK:- View Extensions
extension View {
    
    func setFont(FontName fontName: String, FontSize fSize: CGFloat) -> some View {
        self
            //            .background(Color.black)
            //            .foregroundColor(Color.white)
            .font(.custom(fontName, size: fSize))
        //            .padding(padding)
        
    }
    
    func setShadow(CornerRadius cornerRadius: CGFloat, ShadowColor shadowColor: Color? = .gray, ShadowRadius shadowRadius: CGFloat = 5) -> some View {
        
        self
            .background(Color.white).padding(EdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10)) // Edge Insets
            .background(RoundedRectangle(cornerRadius: cornerRadius)
                            .fill(Color.white)
                            .shadow(color: shadowColor ?? .gray, radius: shadowRadius, x: 0, y: 0))
        
    }
    
    
    //    func setCornerRadius<S>(_ content: S, width: CGFloat = 1, cornerRadius: CGFloat) -> some View where S : ShapeStyle {
    //        let roundedRect = RoundedRectangle(cornerRadius: cornerRadius)
    //        return clipShape(roundedRect)
    //            .overlay(roundedRect.strokeBorder(content, lineWidth: width))
    //    }
    
    func setCustomViewStyle(Padding padding: CGFloat, ForeGroundColor foreGroundColor: Color, BackGroundColor backGroundColor: Color, CornerRadius cornerRadius: CGFloat, Width width: CGFloat,MinHeight minHeight: CGFloat, MaxHeight maxHeight: CGFloat, Alignment alignment: Alignment?) -> some View {
        
        return self
            .padding(padding)
            .frame(maxWidth: width, minHeight: minHeight, maxHeight: maxHeight, alignment: alignment ?? .center)
            .background(backGroundColor)
            .foregroundColor(foreGroundColor)
            .cornerRadius(cornerRadius)
    }
    
    func showShareOptions(ShareMesage dataStr: String) {
        
        //        guard let data = URL(string: dataStr) else { return }
        let av = UIActivityViewController(activityItems: [dataStr], applicationActivities: nil)
        UIApplication.shared.windows.first?.rootViewController?.present(av, animated: true, completion: nil)
    }
    
    
    
    func openSafari(URLStr urlStr: String) {

        if let url = URL(string: urlStr) {
            UIApplication.shared.open(url)
        }
        
        /*
         
         Link(destination: URL(string: "https://www.google.com")!, label: {
             Text("Link")
         })
         .default_ButtonStyle()
         
         */
    }
    
    func showAlert(isPresented: Binding<Bool>,
                   title: String,
                   message: String? = nil,
                   dismissButton: Alert.Button? = nil) -> some View {
        
        alert(isPresented: isPresented) {
            
            Alert(title: Text(title), message: {
                if let message = message {
                    return Text(message)
                }else {
                    return nil
                }
                
            }(), dismissButton: dismissButton)
        }
    }
    
    func showAlert_withTwoActions(isPresented: Binding<Bool>,
                                  title: String,
                                  message: String? = nil,
                                  primaryButton: Alert.Button? = nil, secondaryButton: Alert.Button) -> some View {
        
        alert(isPresented: isPresented) {
            
            Alert(title: Text(title), message: {
                if let message = message {
                    return Text(message)
                }else {
                    return nil
                }
                
            }(), primaryButton: primaryButton ?? .cancel(), secondaryButton: secondaryButton)
        }
    }
        
}

//MARK:- Print in ContentView or anywhere
extension View {
    
    func Perform(_ block: () -> Void) -> some View {
        block()
        return EmptyView()
    }
    
    func printReplace(_ vars: Any...) -> some View {
        for v in vars { print(v) }
        return EmptyView()
    }
}


//MARK:- Corner radius with Border

/// SetConrerRadius

/*
 Usage: .modifier(SetCornerRadius(width: 3, color: .gray, cornerRadius: 10))
 */

struct SetCornerRadius: ViewModifier {
    let width: CGFloat
    let color: Color
    let cornerRadius: CGFloat
    
    func body(content: Content) -> some View {
        content.cornerRadius(cornerRadius - width)
            .padding(width)
            .background(color)
            .cornerRadius(cornerRadius)
    }
}



struct ButtonGradientBackgroundStyle: ButtonStyle {
    
    var padding: CGFloat
    var foregroundColor: Color = .black
    var cornerRadius: CGFloat
    var startColor: Color
    var endColor: Color
    
    
    func makeBody(configuration: Self.Configuration) -> some View {
        configuration.label
            .frame(maxWidth: .infinity)
            .padding(padding)
            .foregroundColor(foregroundColor)
            .background(LinearGradient(gradient: Gradient(colors: [startColor, endColor]), startPoint: .leading, endPoint: .trailing).opacity(configuration.isPressed ? 0.5 : 1))
            .cornerRadius(cornerRadius)
            .padding(.horizontal, 20)
            .shadow(radius: 10)
    }
}

//MARK:- Animations

/*
 
 Usage:
 
 .animateForever(autoreverses: true) { scale = 0.5 }
 
 */

extension AnyTransition {
    static var myOpacity: AnyTransition { get {
        AnyTransition.modifier(
            active: MyOpacityModifier(opacity: 0),
            identity: MyOpacityModifier(opacity: 1))
    }
    }
}

struct MyOpacityModifier: ViewModifier {
    let opacity: Double
    
    func body(content: Content) -> some View {
        content.opacity(opacity)
    }
}


//MARK:- Remove Separator in List

struct ListSeparatorStyle: ViewModifier {
    
    let style: UITableViewCell.SeparatorStyle
    let verticalScrollIndicator: Bool
    
    func body(content: Content) -> some View {
        content
            .onAppear() {
                UITableView.appearance().separatorStyle = self.style
                UITableView.appearance().showsVerticalScrollIndicator = self.verticalScrollIndicator
            }
    }
}

extension View {
    
    func listSeparatorStyle(style: UITableViewCell.SeparatorStyle, verticalIndicator: Bool) -> some View {
        ModifiedContent(content: self, modifier: ListSeparatorStyle(style: style, verticalScrollIndicator: verticalIndicator))
    }
}
//MARK:- Text
extension Text {
    enum Kind {
        case primary
        case secondary
    }
    
    func style1(_ kind: Kind) -> some View {
        
        switch kind {
        case .primary:
            return self
                .padding()
                //                .background(Color.black)
                .foregroundColor(Color.white)
                .font(.largeTitle)
                .cornerRadius(10)
            
        case .secondary:
            return self
                .padding()
                //                .background(Color.blue)
                .foregroundColor(Color.red)
                .font(.largeTitle)
                .cornerRadius(20)
            
        }
    }
}


/// Usage:
/*
 struct ContentView: View {
 @State var kind = Text.Kind.primary
 
 var body: some View {
 VStack {
 Text("Primary")
 .style(kind)
 Button(action: {
 self.kind = .secondary
 }) {
 Text("Change me to secondary")
 }
 }
 }
 }
 */

//extension Bundle {
//    
//    private static var bundle: Bundle!
//
//    public static func localizedBundle() -> Bundle! {
//        if bundle == nil {
//            let appLang = UserDefaults.standard.string(forKey: "app_lang") ?? "ar"
//            let path = Bundle.main.path(forResource: appLang, ofType: "lproj")
//            bundle = Bundle(path: path!)
//        }
//
//        return bundle;
//    }
//
//    public static func setLanguage(lang: String) {
//        UserDefaults.standard.set(lang, forKey: "app_lang")
//        let path = Bundle.main.path(forResource: lang, ofType: "lproj")
//        bundle = Bundle(path: path!)
//    }
//}
//
//extension String {
//    func localized() -> String {
//        return NSLocalizedString(self, tableName: nil, bundle: Bundle.localizedBundle(), value: "", comment: "")
//    }
//
//    func localizeWithFormat(arguments: CVarArg...) -> String{
//        return String(format: self.localized(), arguments: arguments)
//    }
//}


