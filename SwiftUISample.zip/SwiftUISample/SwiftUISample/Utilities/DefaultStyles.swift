//
//  DefaultStyles.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/22/21.
//

import Foundation
import SwiftUI

extension View {
    
    //MARK:- Default Styles

    func defaultStyle() -> some View {
        
        return self
            .buttonStyle(CustomButtonStyle(fontName: .HelveticaNeue_bold, fontSize: 20, padding: 10, backGroundColor: .secondary, foregroundColor: .white, cornerRed: 10, width: .infinity, height: 50, alignment: .center))
    }

    func default_ButtonStyle() -> some View {
        
        return self
            .buttonStyle(CustomButtonStyle(fontName: .HelveticaNeue_bold, fontSize: 20, padding: 10, backGroundColor: .secondary, foregroundColor: .white, cornerRed: 10, width: .infinity, height: 50, alignment: .center))
    }

    func default_MenButtonStyle() -> some View {
        
        return self
            .buttonStyle(CustomButtonStyle(fontName: .HelveticaNeue_bold, fontSize: 20, padding: 10, backGroundColor: .clear, foregroundColor: .black, cornerRed: 10, width: .infinity, height: 45, alignment: .leading))
            .setFont(FontName: Enum_FontName.HelveticaNeue_bold.rawValue, FontSize: 20)
    }

}
