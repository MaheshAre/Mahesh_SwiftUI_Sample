//
//  SKActivityCustom.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/17/21.
//

import Foundation
import UIKit

struct SKActivityCustom {
    
    static let shared = SKActivityCustom()
    private init(){ }
    
    func showLoader(text: String?) {
        
        
        SKActivityIndicator.spinnerColor(UIColor.darkGray)
        SKActivityIndicator.statusTextColor(UIColor.black)
        SKActivityIndicator.statusLabelFont(.systemFont(ofSize: 16, weight: .semibold))
//        let myFont = UIFont(name: "AvenirNext-DemiBold", size: 18)
//        SKActivityIndicator.statusLabelFont(msg.init())
        
        SKActivityIndicator.spinnerStyle(.spinningFadeCircle)
        var statusMessage = ""
        if let message = text {
            statusMessage = message
        }
        SKActivityIndicator.show(statusMessage, userInteractionStatus: true)
    }
    
    func hideLoader() {
        
        SKActivityIndicator.dismiss()
    }
}
