//
//  FTPopoverClass.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/24/21.
//

import Foundation
import SwiftUI

/*
 Usage:
 
 
 CustomUIButton(title: "Drop Down",backGroundColor: .secondaryLabel, foregroundColor: .white, cornerRed: 10, action: { (btn) in
     
     FTPopoverClass.showPopover(Sender: btn, Width: 120, DataArray: self.dropDownArray, ImagesArray: nil) { (selectedIndex) in
         self.selectedString = self.dropDownArray[selectedIndex]
     }
 })
 .frame(width: screenWidth-30, height: 50, alignment: .center)
 
 */

struct FTPopoverClass {
    
    static func showPopover(Sender sender: UIView, Width width: CGFloat = 120, DataArray dataArray: [String], ImagesArray images_array: [UIImage]?, onCompletion: @escaping(_ selectedIndex: Int)->Void) {
        
        let config = FTConfiguration()
        
        config.menuRowHeight = 40
        config.menuWidth = width
        config.backgoundTintColor = UIColor.systemGroupedBackground
        config.borderColor = UIColor.lightGray
        config.menuSeparatorColor = UIColor.lightGray
        config.cornerRadius = 6
        config.textFont = .systemFont(ofSize: 15, weight: .semibold)
        config.textColor = .black
        config.textAlignment = NSTextAlignment.left
        
        FTPopOverMenu.showForSender(sender: sender,
                                    with: dataArray,
                                    menuImageArray: images_array,
                                    popOverPosition: .automatic,
                                    config: config,
                                    done: { (selectedIndex) -> () in
                                        
                                        onCompletion(selectedIndex)
                                    }) {
            
        }
    }
}
