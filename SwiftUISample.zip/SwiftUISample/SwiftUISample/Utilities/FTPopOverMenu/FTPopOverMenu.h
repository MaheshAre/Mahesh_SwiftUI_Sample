//
//  FTPopOverMenu.h
//  FTPopOverMenu
//
//  Created by Wincarn on 2021/1/29.
//

#import <Foundation/Foundation.h>

//! Project version number for FTPopOverMenu.
FOUNDATION_EXPORT double FTPopOverMenuVersionNumber;

//! Project version string for FTPopOverMenu.
FOUNDATION_EXPORT const unsigned char FTPopOverMenuVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FTPopOverMenu/PublicHeader.h>


