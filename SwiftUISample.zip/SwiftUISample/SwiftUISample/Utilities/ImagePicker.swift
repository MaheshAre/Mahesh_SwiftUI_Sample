////
////  ImagePicker.swift
////  SwiftUISample
////
////  Created by IC-MAC004 on 3/8/21.
////
//

import Foundation
import SwiftUI
import UIKit

/*
 
 Usage:
 
 @State private var selectedImage: UIImage?
 @Environment(\.viewController) private var viewControllerHolder: UIViewController?
 
 
 
 Button(action: {
     
     ImagePickerAlertController.showAlertActionSheet(title: "Select Mode", message: "") { (sourceType, isCancelled) in
         
         if isCancelled == false {
             
             self.viewControllerHolder?.present(style: .popover, builder: {
                 
                 ImagePicker(sourceType: sourceType, onImagePicked: { image in
                     self.selectedImage = image
                 })
             })
             
         }
         
     }
     
     
 }, label: {
     Text("Select Image")
         .font(.title)
         .padding()
 })
 
 */

public struct ImagePicker: UIViewControllerRepresentable {
    
    private var sourceType: UIImagePickerController.SourceType
    private let onImagePicked: (UIImage) -> Void
    @Environment(\.presentationMode) private var presentationMode
    
    @Environment(\.viewController) private var viewControllerHolder: UIViewController?
    
    public init(sourceType: UIImagePickerController.SourceType, onImagePicked: @escaping (UIImage) -> Void) {
        self.sourceType = sourceType
        self.onImagePicked = onImagePicked
    }
    
    public func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = self.sourceType
        picker.delegate = context.coordinator
        return picker
    }
    
    public func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    
    public func makeCoordinator() -> Coordinator {
        Coordinator(
            onDismiss: {
                
                self.presentationMode.wrappedValue.dismiss()
                self.viewControllerHolder?.dismiss(animated: true, completion: nil)
            },
            onImagePicked: self.onImagePicked
        )
    }
    
    final public class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        
        private let onDismiss: () -> Void
        private let onImagePicked: (UIImage) -> Void
        
        init(onDismiss: @escaping () -> Void, onImagePicked: @escaping (UIImage) -> Void) {
            self.onDismiss = onDismiss
            self.onImagePicked = onImagePicked
        }
        
        public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            if let image = info[.originalImage] as? UIImage {
                self.onImagePicked(image)
            }
            self.onDismiss()
        }
        
        public func imagePickerControllerDidCancel(_: UIImagePickerController) {
            self.onDismiss()
        }
        
    }
    
}

struct ImagePickerAlertController {
    
    static func showAlertActionSheet(title: String = "", message: String, onCompletion: @escaping((_ action: UIImagePickerController.SourceType, _ isCancelled: Bool)->Void)) {
        
        let alertView = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        
        let action_camera = UIAlertAction(title: "Camera", style: .default) { (action) in
            onCompletion(.camera, false)
        }
        let action_album = UIAlertAction(title: "Gallery", style: .default) { (action) in
            onCompletion(.photoLibrary, false)
        }
        let action_cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
            onCompletion(.photoLibrary, true)
        }
        alertView.addAction(action_camera)
        alertView.addAction(action_album)
        alertView.addAction(action_cancel)
        
        UIWindow.key?.rootViewController?.present(alertView, animated: true, completion: nil)
    }
}


enum Enum_ImagePickerSource {
    case camera
    case album
    case cancel
}

//MARK:- Create ViewController Functionality in ContentView and etc

/*
 
 Usage:
 
 @Environment(\.viewController) private var viewControllerHolder: UIViewController?
 
 
 self.viewControllerHolder?.present(style: .popover, builder: {
     
     ImagePicker(sourceType: sourceType, onImagePicked: { image in
         self.selectedImage = image
     })
 })
 
 or
 
 self.viewControllerHolder?.dismiss(animated: true, completion: nil)
 
 */

struct ViewControllerHolder {
    weak var value: UIViewController?
}

struct ViewControllerKey: EnvironmentKey {
    static var defaultValue: ViewControllerHolder {
        return ViewControllerHolder(value: UIApplication.shared.windows.first?.rootViewController)

    }
}

extension EnvironmentValues {
    var viewController: UIViewController? {
        get { return self[ViewControllerKey.self].value }
        set { self[ViewControllerKey.self].value = newValue }
    }
}

extension UIViewController {
    
    func present<Content: View>(style: UIModalPresentationStyle = .automatic, @ViewBuilder builder: () -> Content) {
        
        let toPresent = UIHostingController(rootView: AnyView(EmptyView()))
        toPresent.modalPresentationStyle = style
        toPresent.rootView = AnyView(
            builder()
                .environment(\.viewController, toPresent)
        )
        NotificationCenter.default.addObserver(forName: Notification.Name(rawValue: "dismissModal"), object: nil, queue: nil) { [weak toPresent] _ in
            toPresent?.dismiss(animated: true, completion: nil)
        }
        self.present(toPresent, animated: true, completion: nil)
    }
    
}

