//
//  Date+Extension.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/5/21.
//

// String to Date, String to String, , Date to Date
// Date to String

import Foundation

//MARK:- Get Current Date
func getCurrentDate() -> Date {
    
    var comp: DateComponents = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: Date())
    comp.calendar = Calendar.current
    comp.timeZone = TimeZone(abbreviation: "GMT")!
    return Calendar.current.date(from: comp)!
}

//MARK:- String -> Date
extension String {
    
    /// Converting String Date to Date()
    func toDate(InputFormat inFormat: Enum_DateFormats? = .yyyymmddHHmmss, OutPutFormat outFormat: Enum_DateFormats? = .ddMMyyyy) -> Date {
        
        let inFormat = (inFormat != nil) ? inFormat! : Enum_DateFormats.yyyymmddHHmmss
        let outFormat = (outFormat != nil) ? outFormat! : Enum_DateFormats.yyyymmddHHmmss
                
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = inFormat.get() //"EEE, dd MMM yyyy hh:mm:ss +zzzz"

        let dateObj = dateFormatter.date(from: self)
        
        let finaleDateStr = dateObj!.toString(Date: dateObj, InputFormat: inFormat, OutPutFormat: outFormat)

        dateFormatter.dateFormat = outFormat.get() //"MM-dd-yyyy"
        dateFormatter.locale = .current
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT")//.current
        
        let finalDate = dateFormatter.date(from: finaleDateStr)
        
        return finalDate ?? Date()
    }
    
}

//MARK:- Date Extensions
extension Date {
    
    /// Converting Date to String Date
    func toString(Date date: Date? = Date(), InputFormat inFormat: Enum_DateFormats? = .yyyymmddHHmmss, OutPutFormat outFormat: Enum_DateFormats? = .yyyymmddHHmmss) -> String {
        
        let date = (date != nil) ? date! : self
        let inFormat = (inFormat != nil) ? inFormat! : Enum_DateFormats.yyyymmddHHmmss
        let outFormat = (outFormat != nil) ? outFormat! : Enum_DateFormats.yyyymmddHHmmss
        
        let dateFormatter = DateFormatter()
        // initially set the format based on your datepicker date / server String
        dateFormatter.dateFormat = inFormat.get()
        dateFormatter.locale = .current
        dateFormatter.timeZone = .current

        let myString = dateFormatter.string(from: date) // string purpose I add here
        // convert your string to date
        let yourDate = dateFormatter.date(from: myString)
        
        //then again set the date format whhich type of output you need
        dateFormatter.dateFormat = outFormat.get()//"dd-MMM-yyyy"
        dateFormatter.locale = .current
        dateFormatter.timeZone = .current
        
        // again convert your date to string
        let myStringafd = dateFormatter.string(from: yourDate!)

        return myStringafd
    }
    /// Get 24 hrs format Time
    func timeIn24HourFormat() -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .none
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: self)
    }
    
    /// Get 12 hrs format Time
    func timeIn12HourFormat() -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .none
        formatter.dateFormat = "hh:mm:ss"
        return formatter.string(from: self)
    }
    
    /// Add Minutes from Given DateTime
    func addMinutes(mins: Int) -> Date {
        let nextMin = Calendar.current.date(byAdding: .minute, value: mins, to: self)
        return nextMin ?? Date()
    }
    
    /// Remove Minutes from Given DateTime
    func removeMinutes(mins: Int) -> Date {
        let previousMin = Calendar.current.date(byAdding: .minute, value: -mins, to: self)
        return previousMin ?? Date()
    }
    
    /// Add Hours from Given DateTime
    func addHours(hrs: Int) -> Date {
        let nextHour = Calendar.current.date(byAdding: .hour, value: hrs, to: self)
        return nextHour ?? Date()
    }
    
    /// Remove Hours from Given DateTime
    func removeHours(hrs: Int) -> Date {
        let previousHour = Calendar.current.date(byAdding: .hour, value: -hrs, to: self)
        return previousHour ?? Date()
    }
    
    /// Get Next Dates from Given Date
    func addDates(days: Int) -> Date {
        let nextDate = Calendar.current.date(byAdding: .day, value: days, to: self)
        return nextDate ?? Date()
    }
    
    /// Get Previous Dates from Given Date
    func removeDates(days: Int) -> Date {
        let previousDate = Calendar.current.date(byAdding: .day, value: -days, to: self)
        return previousDate ?? Date()
    }
    
    /// Get Date by Added Month(s)
    func addMonths(numberOfMonths: Int) -> Date {
        let endDate = Calendar.current.date(byAdding: .month, value: numberOfMonths, to: self)
        return endDate ?? Date()
    }
    
    /// Get Date by Remove Month(s)
    func removeMonths(numberOfMonths: Int) -> Date {
        let endDate = Calendar.current.date(byAdding: .month, value: -numberOfMonths, to: self)
        return endDate ?? Date()
    }
    
    /// Get Date by Added Year(s)
    func addYears(numberOfYears: Int) -> Date {
        let endDate = Calendar.current.date(byAdding: .year, value: numberOfYears, to: self)
        return endDate ?? Date()
    }
    
    /// Get Date by Remove Year(s)
    func removeYears(numberOfYears: Int) -> Date {
        let endDate = Calendar.current.date(byAdding: .year, value: -numberOfYears, to: self)
        return endDate ?? Date()
    }
    
    var startOfDay: Date {
        return Calendar.current.startOfDay(for: self)
    }
    
    func daysBetween(_ date: Date) -> Int {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.day], from: self.startOfDay, to: date.startOfDay)
        
        return components.day!
    }
    
    var numberOfWeeksInMonth: Int {
            let calendar = Calendar.current
            let weekRange = (calendar as NSCalendar).range(of: NSCalendar.Unit.weekOfYear, in: NSCalendar.Unit.month, for: self)
            
            return weekRange.length
        }
    
    /// Get Time Since Ago based on Dates
    func timeSinceDate(fromDate: Date) -> String {
        
        let earliest = self < fromDate ? self  : fromDate
        let latest = (earliest == self) ? fromDate : self
        
        let components:DateComponents = Calendar.current.dateComponents([.minute,.hour,.day,.weekOfYear,.month,.year,.second], from: earliest, to: latest)
        let year = components.year  ?? 0
        let month = components.month  ?? 0
        let week = components.weekOfYear  ?? 0
        let day = components.day ?? 0
        let hours = components.hour ?? 0
        let minutes = components.minute ?? 0
        let seconds = components.second ?? 0
                
        if year >= 2 {
            return "\(year) years ago"
        }else if (year >= 1){
            return "1 year ago"
        }else if (month >= 2) {
            return "\(month) months ago"
        }else if (month >= 1) {
            return "1 month ago"
        }else  if (week >= 2) {
            return "\(week) weeks ago"
        } else if (week >= 1){
            return "1 week ago"
        } else if (day >= 2) {
            return "\(day) days ago"
        } else if (day >= 1){
            return "1 day ago"
        } else if (hours >= 2) {
            return "\(hours) hours ago"
        } else if (hours >= 1){
            return "1 hour ago"
        } else if (minutes >= 2) {
            return "\(minutes) minutes ago"
        } else if (minutes >= 1){
            return "1 minute ago"
        } else if (seconds >= 3) {
            return "\(seconds) seconds ago"
        } else {
            return "Just now"
        }
        
    }
    
    func time(since fromDate: Date) -> String {
        
        let earliest = self < fromDate ? self : fromDate
        let latest = (earliest == self) ? fromDate : self
        
        let allComponents: Set<Calendar.Component> = [.minute, .hour, .day, .weekOfYear, .month, .year, .second]
        let components:DateComponents = Calendar.current.dateComponents(allComponents, from: earliest, to: latest)
        let year = components.year  ?? 0
        let month = components.month  ?? 0
        let week = components.weekOfYear  ?? 0
        let day = components.day ?? 0
        let hour = components.hour ?? 0
        let minute = components.minute ?? 0
        let second = components.second ?? 0
        
        let descendingComponents = ["year": year, "month": month, "week": week, "day": day, "hour": hour, "minute": minute, "second": second]
        for (period, timeAgo) in descendingComponents {
            if timeAgo > 0 {
                return "\(timeAgo.of(period)) ago"
            }
        }
        
        return "Just now"
    }
    
    /// Get Human Readable Week name
    func getWeekName() -> String {
        let weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
        
        let calendar = Calendar.current.component(.weekday, from: self)
        return weekdays[calendar - 1]
    }
    
    var millisecondsSince1970:Int64 {
        return Int64((self.timeIntervalSince1970 * 1000.0).rounded())
    }
    
    func milliSecondsToDate(milliseconds:Int64) -> Date {
        
        return Date(timeIntervalSince1970: TimeInterval(milliseconds) / 1000)
    }
}

extension Int {
    func of(_ name: String) -> String {
        guard self != 1 else { return "\(self) \(name)" }
        return "\(self) \(name)s"
    }
}

//MARK:- Date Comparisions

struct DateComparsionResult {
    var value = 0
    var dateMessage = ""
}

extension Date {
    
    func compare(date:Date, compareDate:Date) -> DateComparsionResult {
        
        var dateComrisionResult = DateComparsionResult()
        let result:ComparisonResult = date.compare(compareDate)
        switch result {
        case .orderedAscending:
            dateComrisionResult.value = 1
            dateComrisionResult.dateMessage = "Future Date"
            break
        case .orderedDescending:
            dateComrisionResult.value = -1
            dateComrisionResult.dateMessage = "Past Date"
            break
        case .orderedSame:
            dateComrisionResult.value = 0
            dateComrisionResult.dateMessage = "Same Date"
            break
        default:
            dateComrisionResult.value = 10
            dateComrisionResult.dateMessage = "Error Date"
            break
        }
        return dateComrisionResult
    }
}

/*
 
 Wednesday, Sep 12, 2018           --> EEEE, MMM d, yyyy
 09/12/2018                        --> MM/dd/yyyy
 09-12-2018 14:11                  --> MM-dd-yyyy HH:mm
 Sep 12, 2:11 PM                   --> MMM d, h:mm a
 September 2018                    --> MMMM yyyy
 Sep 12, 2018                      --> MMM d, yyyy
 Wed, 12 Sep 2018 14:11:54 +0000   --> E, d MMM yyyy HH:mm:ss Z
 2018-09-12T14:11:54+0000          --> yyyy-MM-dd'T'HH:mm:ssZ
 12.09.18                          --> dd.MM.yy
 10:41:02.112                      --> HH:mm:ss.SSS
 
 */

//MARK:- Date Formats
enum Enum_DateFormats {
    
    ///24 hrs format
    case yyyymmddHHmmss
    ///12 hrs format
    case yyyymmddhhmmss
    case ddMMyyyy
    /// 24 Hrs Time
    case HHmmss
    /// 12 Hrs Time
    case hhmmss
    
    case short
    
    /// Retuns Dynamic Value
    case other(format: String)
    
    func get() -> String {
        
        switch self {
        case .yyyymmddHHmmss: return "yyyy-MM-dd HH:mm:ss"
        case .yyyymmddhhmmss: return "yyyy-MM-dd hh:mm:ss"
        case .ddMMyyyy: return "dd-MM-yyyy"
        case .HHmmss: return "HH:mm:ss"
        case .hhmmss: return "hh:mm:ss"
        case .short: return "MM/dd/yy, hh:mm"
            
            
            /// Return Dynamic parameter
        case let .other(self): return self
            

        }
    }
}



