//
//  Userdefaults+Extension.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 3/17/21.
//

import Foundation
import SwiftUI

let user_defaults = UserDefaults.standard

    
    func remove_userdeaultsData() {
        
        let domain = Bundle.main.bundleIdentifier!
        user_defaults.removePersistentDomain(forName: domain)
        user_defaults.synchronize()
                
    }
