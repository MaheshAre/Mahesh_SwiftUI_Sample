//
//  TF+Extension.swift
//  SwiftUISample
//
//  Created by IC-MAC004 on 2/22/21.
//

import Foundation
import SwiftUI


struct MyTextFieldStyle: TextFieldStyle {
    
    
    
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
        .padding(10)
        .background(
            RoundedRectangle(cornerRadius: 5, style: .continuous)
                .stroke(Color.red, lineWidth: 3)
        ).padding()
    }
}

extension View {
    
    func setUnderlineTextField(uColor: Color = .black) -> some View {
        self
            .padding(.vertical, 10)
            .overlay(Rectangle().frame(height: 2).padding(.top, 35))
            .foregroundColor(uColor)
            .padding(10)
    }
    
}

extension View {
    
    func CustomTextField(PlaceHolder placeHolder: String,
                         BindingString bindingString: Binding<String>,
                         FontName fontName: Enum_FontName = .System_regular,
                         FontSize fontSize: CGFloat = 17,
                         KeyBoardType keyboardType: UIKeyboardType = .default,
                         Height height: CGFloat = 40,
                         LeftPadding leftPadding: CGFloat = 10,
                         RightPadding rightPadding: CGFloat = 10,
                         CornerRadius cornerRadius: CGFloat = 5,
                         FontColor fontColor:Color = .black,
                         BorderWidth borderWidth: CGFloat = 1,
                         BorderColor borderColor: Color = .gray) -> some View {
        
        let TF = TextField(placeHolder, text: bindingString)
            .keyboardType(keyboardType)
            .setFont(FontName: fontName.rawValue, FontSize: fontSize)
            .frame(height: height)
            .textFieldStyle(PlainTextFieldStyle())
//            .padding([.leading, .trailing], 4)
            .padding(.leading, leftPadding)
            .padding(.trailing, rightPadding)
            .overlay(RoundedRectangle(cornerRadius: cornerRadius).stroke(borderColor, lineWidth: borderWidth))

        
        return TF
    }
    
    func CustomSecureTextField(PlaceHolder placeHolder: String,
                         BindingString bindingString: Binding<String>,
                         FontName fontName: Enum_FontName = .System_regular,
                         FontSize fontSize: CGFloat = 17,
                         KeyBoardType keyboardType: UIKeyboardType = .default,
                         Height height: CGFloat = 40,
                         LeftPadding leftPadding: CGFloat = 10,
                         RightPadding rightPadding: CGFloat = 10,
                         CornerRadius cornerRadius: CGFloat = 5,
                         FontColor fontColor:Color = .black,
                         BorderWidth borderWidth: CGFloat = 1,
                         BorderColor borderColor: Color = .gray) -> some View {
        
        let TF = SecureField(placeHolder, text: bindingString)
            .keyboardType(keyboardType)
            .setFont(FontName: fontName.rawValue, FontSize: fontSize)
            .frame(height: height)
            .textFieldStyle(PlainTextFieldStyle())
//            .padding([.leading, .trailing], 4)
            .padding(.leading, leftPadding)
            .padding(.trailing, rightPadding)
            .overlay(RoundedRectangle(cornerRadius: cornerRadius).stroke(borderColor, lineWidth: borderWidth))

        
        return TF
    }
    
    /*
     
     TextField with Image
     
     ZStack(alignment: Alignment(horizontal: .trailing, vertical: .center), content: {
         
         CustomSecureTextField(PlaceHolder: "Password", BindingString: self.$vmLogin.params.password, RightPadding: 50)
         Button("   ") {
             self.isShowPassword.toggle()
             self.endEditing()
         }
         .padding()
         .background(self.isShowPassword ? Image("icon_show") : Image("icon_hide"))
         
     })
     
     */
    
}

//MARK:- Validations

extension String {
    
    func isValid_TF(count: Int) -> Bool {
        
        return  count < self.count ? true : false
        
    }
    
    func isValid_Email() -> Bool {
        
        
//        let emailFormat = "(?:[\\p{L}0-9!#$%\\&'*+/=?\\^_`{|}~-]+(?:\\.[\\p{L}0-9!#$%\\&'*+/=?\\^_`{|}" + "~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\" + "x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[\\p{L}0-9](?:[a-" + "z0-9-]*[\\p{L}0-9])?\\.)+[\\p{L}0-9](?:[\\p{L}0-9-]*[\\p{L}0-9])?|\\[(?:(?:25[0-5" + "]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-" + "9][0-9]?|[\\p{L}0-9-]*[\\p{L}0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21" + "-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])"
        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        return emailPredicate.evaluate(with: self)
    }
    
    func isValid_MobileNumber() -> Bool {
        
        var isValidContact: Bool {
            let phoneNumberRegex = "^[6-9]\\d{9}$"
            let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneNumberRegex)
            let isValidPhone = phoneTest.evaluate(with: self)
            return isValidPhone
        }
        
        return isValidContact
    }
}

//MARK:- Limit in TextField
 
/*
 Usage:
 @ObservedObject var TF_mobile = TextFieldLimitManager(limit: 10)
 
 TextField("Mobile Number", text: self.$TF_mobile.text)
     .modifier(TF_ViewModifier(fontName: .HelveticaNeue_regular, textSize: 15, roundedCornes: 5, borderColor: .gray, borderWidth: 1, textColor: .black, paddingValue: 10, keyBoardType: .numberPad))
 
 if self.TF_mobile.text.isValid_MobileNumber() == false {
     self.isShowMobile = true
 }
 
 
 */
class TextFieldLimitManager: ObservableObject {
    @Published var text = "" {
        didSet {
            if text.count > characterLimit && oldValue.count <= characterLimit {
                text = oldValue
            }
        }
    }
    let characterLimit: Int

    init(limit: Int = 5){
        characterLimit = limit
    }
}


//MARK:- TF with Image

/*
 
 HStack {
     
     Image(systemName: "lock")
     TextField("Password", text: $TF_password)
         .setFont(FontName: Enum_FontName.HelveticaNeue_regular.rawValue, FontSize: 15)
                 //.constant("typed text")).foregroundColor(Color.red).font(Font.custom("Papyrus", size: 16))
     
 }
 .padding()
 .overlay(RoundedRectangle(cornerRadius: 5).stroke(lineWidth: 1).foregroundColor(Color.gray))
 
 ---------------------------------------------------
 
 HStack {
     
     
     TextField("Password", text: $TF_password)
         .setFont(FontName: Enum_FontName.HelveticaNeue_regular.rawValue, FontSize: 15)
     Button("") {
         
     }
     //.background(Image(systemName: "icon_show"))
     .background(Image("icon_show"))
     .frame(width: 15, height: 30, alignment: .center)
                 //.constant("typed text")).foregroundColor(Color.red).font(Font.custom("Papyrus", size: 16))
     
 }
 .padding()
 .overlay(RoundedRectangle(cornerRadius: 5).stroke(lineWidth: 1).foregroundColor(Color.gray))
 
 
 */
